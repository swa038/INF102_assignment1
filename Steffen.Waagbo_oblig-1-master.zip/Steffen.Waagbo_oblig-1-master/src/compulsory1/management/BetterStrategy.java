package compulsory1.management;

import java.util.List;

public class BetterStrategy implements IStrategy{

	@Override
	public void registerRobots(List<Robot> robots) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void registerJob(Job job) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void jobFulfilled(Job job) {
		// TODO Auto-generated method stub
		
	}

}
